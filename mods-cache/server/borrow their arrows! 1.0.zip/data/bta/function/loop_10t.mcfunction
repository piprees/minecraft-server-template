execute at @a run execute as @e[type=arrow,distance=..1] run data modify entity @s pickup set value 1b
schedule function bta:loop_10t 10t